#!/usr/bin/python
import MySQLdb
import MySQLdb.cursors

class db ( object ) :
    # the database class"
    host   = "localhost"
    user   = "root"
    passwd = ""
    dbname = "military"

    def __init__ ( self ) :
        self.conn = MySQLdb.Connection
        self.cur  = MySQLdb.cursors.Cursor

    def connect ( self ) :
        # connect to the database"
        self.conn = MySQLdb.connect ( self.host, self.user, self.passwd, self.dbname )
        self.cur = self.conn.cursor()

    def execute ( self, statement ) :
        # execute the given sql statement"
        self.cur.execute ( statement )
        return self.cur.fetchall() 

    def update(self,statement,values):
        # execute the given sql statement"
        self.cur.execute ( statement,values ) 
        self.conn.commit()

    def show ( self ) :
        # print the first cell of all the rows"
        for row in self.cur.fetchall() :
            print(row[0]) 
            
    def close ( self ) :
        # execute the given sql statement"
        self.cur.close() 
            
x=db()
x.connect()            
x.close()