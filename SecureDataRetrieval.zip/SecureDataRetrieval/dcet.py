x=5 
y="hello"
print('x+y')