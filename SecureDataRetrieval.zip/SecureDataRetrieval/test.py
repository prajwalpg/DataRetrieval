import AES
from Dbcon import db 

x=db()
x.connect() 
fname="AES.py" 
rtecords=x.execute("select * from snfiles where Fname='"+fname+"'") 
verifier=None
for row in rtecords: 
            verifier=row 
keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
if verifier:  
        print(AES.decrypt(verifier[3],keyWord))
