from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import AES
import random
import socket
from Dbcon import db
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

# import thread module
from _thread import *
import threading                 
import time
#import beepy as beep
import json
ex=None
 


print_lock = threading.Lock()

class Window(QWidget):
    label1=None
    btn1=btn2=btn3=btn4=None
    
    keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
    msg_box_name = None 
    width=600
    height=700
    tableWidget=None
    
    def __init__(self):
        super().__init__()
        
        self.initUI()
        
        
    def initUI(self):
        self.createLayout()
        
        start_new_thread(self.listenport1, ("127.0.0.1",3292))
        start_new_thread(self.listenport2, ("127.0.0.1",1299))        
        
        self.msg_box_name=QMessageBox() 
        hbox = QHBoxLayout()
        
        windowLayout = QVBoxLayout()
        windowLayout.addWidget(self.horizontalGroupBox)
        self.setLayout(windowLayout)
        self.setStyleSheet("background-color:#7FB3D5;font-weight:900;font-size:20px;")
        
        self.setFixedSize(QSize(self.width, self.height))
        self.setWindowTitle('DTN Router::Secure Data Retrieval for Decentralized Disruption-Tolerant Military Networks') 
        self.show() 
        
        self.label9.resize(self.frameGeometry().width()-50,int(self.height/2.5)) 
        
        self.label1.resize(self.frameGeometry().width(),int(self.height/5)) 
        
       
        self.label1.setPixmap(self.pixmap.scaled( self.label1.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
         
        #self.label9.setPixmap(self.pixmap8.scaled( self.label9.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
    def createLayout(self):
      
        self.horizontalGroupBox = QGroupBox("")
        self.vbox = QVBoxLayout()
        
        self.label1 = QLabel("")
        self.label2 = QLabel("")
        self.label3 = QLabel("")
        self.label4 = QLabel("")
        self.label5 = QLabel("")
        self.label6 = QLabel("")
        
        self.label7 = QLabel("")
        self.label8 = QLabel("")
        
        
        self.label9 = QLabel("")
        
        
        
        self.label10 = QLabel("")
        self.label11 = QLabel("")
        self.label12 = QLabel("")
        self.label13 = QLabel("")
        self.label14 = QLabel("")
        self.label15 = QLabel("")
        self.label16 = QLabel("")
        
        self.label17 = QLabel("[NoMovement]") 
        self.label17.setStyleSheet("font-size:10px;color:black;")   
        
		# Load image
        self.pixmap = QPixmap('DTNRouter.png')
        self.pixmap1 = QPixmap('send.png')
        self.pixmap2 = QPixmap('ln2.png')
        self.pixmap2g = QPixmap('gln2.png')
        self.pixmap3 = QPixmap('snode.png')  
        self.pixmap4 = QPixmap('ln3.png')
        self.pixmap4g = QPixmap('gln3.png')
        self.pixmap5 = QPixmap('user.png')    

        self.pixmap6 = QPixmap('ln1.png')
        self.pixmap7 = QPixmap('ln5.png')   
        self.pixmap6g = QPixmap('gln1.png')
        self.pixmap7g = QPixmap('gln5.png')            
                 
        
        self.pixmap8 = QPixmap('Block.png')   


        self.pixmap9 = QPixmap('k1.png')
        self.pixmap10 = QPixmap('ln4.png')
        self.pixmap10g = QPixmap('gln4.png')
        self.pixmap11 = QPixmap('KA.png')  
        self.pixmap12 = QPixmap('ln4.png')
        self.pixmap12g = QPixmap('gln4.png')
        self.pixmap13 = QPixmap('k1.png') 
        self.pixmap14 = QPixmap('ln5.png')  
        self.pixmap14g = QPixmap('gln5.png')    
        self.pixmap15 = QPixmap('k1.png')   
		# Set image to label
        self.label2.setPixmap(self.pixmap1)
        self.label3.setPixmap(self.pixmap2)  
        
        self.label4.setPixmap(self.pixmap3) 
        self.label5.setPixmap(self.pixmap4) 
        self.label6.setPixmap(self.pixmap5) 
        self.label7.setPixmap(self.pixmap6) 
        self.label8.setPixmap(self.pixmap7) 

        
        #self.label9.setPixmap(self.pixmap8) 


        self.label10.setPixmap(self.pixmap9)
        self.label11.setPixmap(self.pixmap10) 
        self.label12.setPixmap(self.pixmap11) 
        self.label13.setPixmap(self.pixmap12) 
        self.label14.setPixmap(self.pixmap13) 
        self.label15.setPixmap(self.pixmap14) 
        self.label16.setPixmap(self.pixmap15) 

        # Resize the label according to image size
        layout1 = QGridLayout() 
        layout1.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        layout1.addWidget(self.label1,0,0,1,7)  
        
        self.vbox.addLayout(layout1)
        
        layout2 = QGridLayout() 
        layout2.addWidget(self.label2,0,0)          
        layout2.addWidget(self.label3,0,1,1,2)          
        layout2.addWidget(self.label4,0,3)          
        layout2.addWidget(self.label5,0,4,1,2)          
        layout2.addWidget(self.label6,0,6)       
        
        layout2.addWidget(QLabel("Sender"),1,0)       
        layout2.addWidget(QLabel("Storage Node"),1,3)   
        layout2.addWidget(QLabel("Users"),1,6)      
        
        self.vbox.addLayout(layout2)
 
        layout3 = QGridLayout() 
        layout3.addWidget(self.label7,0,0,2,2)              
        layout3.addWidget(self.label8,0,2)       
        layout3.addWidget(self.label17,0,6)     
        
        self.vbox.addLayout(layout3)  
                
        
        container =  QWidget() 
        layout4 = QGridLayout()  
        container.setStyleSheet("background-color:#fff;") 
        
        #layout4.addWidget(self.label9,1,0,1,1)  
        
        
        layout4.addWidget(self.label10,2,1)          
        layout4.addWidget(self.label11,2,2)          
        layout4.addWidget(self.label12,2,3)          
        layout4.addWidget(self.label13,2,4)          
        layout4.addWidget(self.label14,2,5)       
        
        layout4.addWidget(QLabel("KA1"),3,1)      
        layout4.addWidget(QLabel("KA2"),3,5)   
        layout4.addWidget(self.label15,3,3)      
                
        layout4.addWidget(self.label16,4,3)
        layout4.addWidget(QLabel("KA3"),5,3)   
        container.setLayout(layout4)
        
        self.vbox.addWidget(container)            
        
        
        self.label1.resize(self.width,self.height)
        
        
        self.horizontalGroupBox.setLayout(self.vbox)
        
    # thread fuction
    def threaded1(self,c):
        BUFF_SIZE=2048
        while True:

        # data received from client
           data = c.recv(BUFF_SIZE)
           if not data:  
               break
           else:
             if len(data) >= BUFF_SIZE: 
                while True:
                  part = c.recv(BUFF_SIZE)
                  data += part
                  if len(part) < BUFF_SIZE: 
                     break
             data=json.loads(data)         
             src=data[0] 
             res=data[1]    
             self.label5.setPixmap(self.pixmap4g)
             self.label8.setPixmap(self.pixmap7g) 
            
             self.label17.setText(res)
             if res.lower()=="success" or res.lower()=="data":
               self.label17.setStyleSheet("font-size:30px;font-weight:900;color:green;")      
             else:
               self.label17.setStyleSheet("font-size:30px;font-weight:900;color:red;")      
              
             lbl=None 
             counter=1 
             
             while True:   
               self.label9.resize(self.frameGeometry().width()-50,int(self.height/2.5)) 
               '''if res.lower()=="success" or res.lower()=="data":
                  beep.beep(sound=1)
               else:
                  beep.beep(sound=3)   '''             
               time.sleep(1)
               self.label5.setPixmap(self.pixmap4g if (counter % 2)==0 else self.pixmap4)
               self.label8.setPixmap(self.pixmap7g if (counter % 2)==0 else self.pixmap7)
               if (counter % 2)==0:
                 if res.lower()=="success" or res.lower()=="data":
                    self.label17.setStyleSheet("font-size:30px;font-weight:900;color:green;")      
                 else:
                    self.label17.setStyleSheet("font-size:30px;font-weight:900;color:red;")      
               else:
                    self.label17.setStyleSheet("font-size:30px;font-weight:900;color:black;")      
                               
               
               if src.lower()=="ka1":   
                     self.label11.setPixmap(self.pixmap12g if (counter % 2)==0 else self.pixmap12) 
               if src.lower()=="ka2":   
                     self.label13.setPixmap(self.pixmap12g if (counter % 2)==0 else self.pixmap12) 
               if src.lower()=="ka3":   
                     self.label15.setPixmap(self.pixmap14g if (counter % 2)==0 else self.pixmap14) 
               counter+=1
               if counter==9: 
                  break
             
            
             self.label5.setPixmap(self.pixmap4)
             self.label8.setPixmap(self.pixmap7) 
             self.label17.setText("[NoMovement]") 
             self.label17.setStyleSheet("font-size:10px;color:black;")    
             if src.lower()=="ka1":   
                self.label11.setPixmap(self.pixmap12) 
             if src.lower()=="ka2":   
                self.label13.setPixmap(self.pixmap12) 
             if src.lower()=="ka3":   
                self.label15.setPixmap(self.pixmap14) 
             break         
             
    def listenport1(self,host,port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(5)
        while True:

        # establish connection with client
               c, addr = s.accept()

        # lock acquired by client 
        # Start a new thread and return its identifier
               start_new_thread(self.threaded1, (c,))
        s.close()
        
          # thread fuction
    def threaded2(self,c):
        BUFF_SIZE=2048
        while True:

        # data received from client
           data = c.recv(BUFF_SIZE)
           if not data:  
               break
           else:
             if len(data) >= BUFF_SIZE: 
                while True:
                  part = c.recv(BUFF_SIZE)
                  data += part
                  if len(part) < BUFF_SIZE: 
                     break
             data=json.loads(data)         
             src=data[0] 
             fname=data[1] 
             sk=data[2] 
             
             Aut=None
             Bat=None
             Reg=None
             lbl=None
             if src.lower()=="upload":
                Aut=data[3]   if len(data)>3 else ""
                Bat=data[4]   if len(data)>3 else ""
                Reg=data[5]   if len(data)>3 else ""
                lbl=self.label3
                self.label3.setPixmap(self.pixmap2g) 
                
             self.label7.setPixmap(self.pixmap6g)
             self.label17.setStyleSheet("font-size:30px;font-weight:900;color:green;")  
             self.label17.setText(fname)
             if src.lower()=="ka1":   
                self.label11.setPixmap(self.pixmap12g)
                lbl=self.label11
             if src.lower()=="ka2":   
                self.label13.setPixmap(self.pixmap12g)
                lbl=self.label13
             if src.lower()=="ka3":   
                self.label15.setPixmap(self.pixmap14g)
                lbl=self.label15
             counter=1
                          
             while True:   
               self.label9.resize(self.frameGeometry().width()-50,int(self.height/2.5))    
               #beep.beep(sound=1)       
               time.sleep(2) 
               self.label7.setPixmap(self.pixmap6g if (counter % 2)==0 else self.pixmap6) 
               if (counter % 2)==0: 
                    self.label17.setStyleSheet("font-size:30px;font-weight:900;color:green;")      
               else:
                    self.label17.setStyleSheet("font-size:30px;font-weight:900;color:black;")      
               if src.lower()=="ka1":   
                     self.label11.setPixmap(self.pixmap12g if (counter % 2)==0 else self.pixmap12) 
               if src.lower()=="ka2":   
                     self.label13.setPixmap(self.pixmap12g if (counter % 2)==0 else self.pixmap12) 
               if src.lower()=="ka3":   
                     self.label15.setPixmap(self.pixmap14g if (counter % 2)==0 else self.pixmap14) 
               counter+=1
               if counter==9: 
                  break
             
             self.label17.setText("[No Movement]")
             self.label17.setStyleSheet("font-size:30px;font-weight:900;color:black;")   
             self.label7.setPixmap(self.pixmap6) 
             self.label3.setPixmap(self.pixmap2) 
             
             if src.lower()=="ka1":   
                self.label11.setPixmap(self.pixmap12) 
             if src.lower()=="ka2":   
                self.label13.setPixmap(self.pixmap12) 
             if src.lower()=="ka3":   
                self.label15.setPixmap(self.pixmap14) 
             break         
             
    def listenport2(self,host,port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(5)
        while True:

        # establish connection with client
               c, addr = s.accept()

        # lock acquired by client 
        # Start a new thread and return its identifier
               start_new_thread(self.threaded2, (c,))
        s.close()  
    
def main():   
    
    app = QApplication(sys.argv)
    ex = Window()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()