-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2023 at 07:18 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `military`
--

-- --------------------------------------------------------

--
-- Table structure for table `attackers`
--

CREATE TABLE `attackers` (
  `Aname` varchar(255) NOT NULL,
  `Afile` varchar(255) NOT NULL,
  `Akey` varchar(255) NOT NULL,
  `ABat` varchar(255) NOT NULL,
  `AReg` varchar(255) NOT NULL,
  `tym` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attackers`
--

INSERT INTO `attackers` (`Aname`, `Afile`, `Akey`, `ABat`, `AReg`, `tym`) VALUES
('Vijay', 'client.py', 'dsfdsafasd', 'B1', 'R1', '2023-04-13 17:13:39');

-- --------------------------------------------------------

--
-- Table structure for table `kafiles`
--

CREATE TABLE `kafiles` (
  `Fname` varchar(255) NOT NULL,
  `Sk` varchar(255) NOT NULL,
  `KA` varchar(255) NOT NULL,
  `Batalion` varchar(255) NOT NULL,
  `Region` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `keys_ka1`
--

CREATE TABLE `keys_ka1` (
  `Fname` varchar(255) NOT NULL,
  `Keys` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keys_ka1`
--

INSERT INTO `keys_ka1` (`Fname`, `Keys`) VALUES
('AES.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0DltOHehNsmQXi81pVdQ\nz0gvS96NWJ0VQeRPfndc3pfDx5XAN7q4LtBs2mS/6rSgucO1azZzGVGTXo59/FAH\nvu02u/Nis4RHnxlJ5A/QboMp+k5gC0rN0hL75f9vcxASHUTqPyZNZGPfR8NL3UB6\n/tXQNet3w+T/foDYhK+Qt/aqNOySLYrJn+YX5umGYiszCXsMFM4e3evDiVMpS0DL\nIpRdPGQk4ChG3K9rKYdvK/k0SqctnaJsf5WaNyQzpMPCnGqqzhjQV44No3e1t+QM\njGGG8+3IkPkWUTeVBwd1cDKPtYCQcGU+m2dB1JH0f/PnPcsX7IyRkYdR1T/AVsjH\nfQIDAQAB\n-----END PUBLIC KEY-----\n'),
('rsa.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA23bzhRZleusruFKkv57l\nSjSECmT1VU7tg1YcgerFxYJhxk7PLpHlTA0DfgzzLqUc9vPqebI0x/kANS7e1ij5\n0iVs2cTJYRwk91XPC46fgNPRFQeAfay66QJabdRJzTN9f6eX0Zmm1i4bGCn3ZaXh\neQZAZdf4mheytChZdRmBsCQKrzMSiV3k1wvrDET5qvCIBPQ6xHV97FWAYMk16ofX\nTxILdPsA2GxjnXCW7Z0aUfiZhNOZxOvt9wjxk0IFEr8APoxr8+VdEOL0WTvOeygj\nQz08AYKd5OYYVQYk3+d7f3hG29XltCHi/SalDRuOXf8mkKs2twVcg7j3Y7fz/cii\ndQIDAQAB\n-----END PUBLIC KEY-----\n'),
('sender.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl/pNDhD3F/hLujB8ukdO\nvUrDlc1EXmLfZFNU6gMtUBXbLYodiQ48nMioV4CFnfNik7W2QeQU6ylotvtXfYCj\ncpTBYo/GnKA7ibLjdo6dls2xr6zGKjMLqg3UqYP/e2sfrXM1QOi9As3pSqAtpXjF\noC3uEubvVXGDzqdbVwQuJpwq5VUNuJ0Wyofs2r6fODK0lslsh8r1Yl3IuYlbR2/x\nr6kQLIPn5R1BRYDTKxLq1qadH6HbAQapEZOkgu1KKTSdkv3TZGEe2BniEtWDaj8Z\nQ8bu54V5Yx8H9FNGDum1uBtiyKbDp9hioRL21IK5vwEiELC/9fYsGqjz3RLbbx7f\n6QIDAQAB\n-----END PUBLIC KEY-----\n'),
('test.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1r6t9CIXhtw2eYpZzy2J\nRG5GkR0BWwEHiyhRswOVyz0/nvkrids7Hc2pZXs423iFN1j3HSTj5DmAFCXZ4VjV\nJT0uPVP7MQLfQhZH09ujjy1WBOOltvhNRneThDodF1Xejmfr46UldbuL/VSH24xI\nNnAaeQ9h0Ly5DdJP+jAq+HAwtrR9wknesi2yxs9kNKU11kSigCood+vW50ijbnCH\nK7bwJD9cl0HJu3FT7wJVzNeaMYsVkIiKy3lCej7qqb+ISzVB9DBpxVDp3M6a4Tzu\nDkFCdex3mELxDLlSCLPFa6dQTxfshey6VnJwGM5Glo6d/Q6+9XhdviNApVe43/CM\nHQIDAQAB\n-----END PUBLIC KEY-----\n');

-- --------------------------------------------------------

--
-- Table structure for table `keys_ka2`
--

CREATE TABLE `keys_ka2` (
  `Fname` varchar(255) NOT NULL,
  `Keys` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keys_ka2`
--

INSERT INTO `keys_ka2` (`Fname`, `Keys`) VALUES
('client.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsX2h0uHa0AftX2e5wvMQ\nqdxvAlHFzANWU5IphEZ6LZaAT7Tt/Pa3jiEWfnEXvrnTLddp246rs4WeLs9wJkro\nl7gLQRrbZ6o894LF/luIIq16VoXEWX088lcTpds4NaZke54jZLK5y6UyqIyKrAix\nCNZSPrqQ4bwm+BY0m69Ne9fZEvlG143c8BNiU9OwYQRkloPuaM0lARhR5fWADdFS\nXdmsZ4f8pPjXUbJ/+QhzdiMq78SL9N5GVaOYqnIcceFIrhiCVGhp6S1hWbUxidb0\nhCzutD9Q5wKpUxXG4V5iY2ytmbBEMAyDQJX2jQVjZuJry3SqTYZULqY1qG0DsBXg\nlQIDAQAB\n-----END PUBLIC KEY-----\n');

-- --------------------------------------------------------

--
-- Table structure for table `keys_ka3`
--

CREATE TABLE `keys_ka3` (
  `Fname` varchar(255) NOT NULL,
  `Keys` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keys_ka3`
--

INSERT INTO `keys_ka3` (`Fname`, `Keys`) VALUES
('Dbcon.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1Aex6guZqEY+Az9DNcxH\ne6ZK22BcUUwc2u5CrkGHJub2K26q/demg1VZCRmQx80wHUSkiM670YorItgHN9Pq\nRgkHfw5IdvMN8BHDbgbAxLBCOa5CRcPhwlqI4PZ0ZYmgkQl32MTUzxLSfc3umiWO\n+dGN0KB5TT9zZ4++4UERbSCQIA4cYZzGdTj3CHOzGj0WqqOS5443rz0mwYj0bz1Y\n4O7XTPtpfF3SLJMrJ0CYRiHVa9yRJnJShFp867wRZdWbBEF+PtFY7EN70H8OgSWa\nNeXia82kP9DgQjA35kDoUHSsQUMi9DvtpEQkQgs7fzJVoYVn1ZqH+W0iISuUmgnE\nAwIDAQAB\n-----END PUBLIC KEY-----\n'),
('server.py', '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoVMUHaQbWshJO9TW75+q\nRHHLIjxDXJb63G/bNXqoNc7iNm+bl/LPEwHjdmdS58ZljJvo079zFfYNeSqxTJNK\npbm/GGSouoviLP+tIFYeSwLPDV8s9x2osA/9FWHWv6kI0PquwIwIFyULofojER8k\nWFWLpON498WpWlf26H2rGmYZ+RGwFFLObULxD6AspEo0VIwX0F4M8q725OA7YcKz\nVwQdFHv5q0U9VXie35YYb0o1APvh1wVyZyMzBIAaXbz93NyxhGX/hsbe7BSelNSV\ny0sBDAjyWKRjzsox8gbnWVaCuq4DeH/PSJNAGy4oXc3PZyv+YP13V2rY7kaWaxUB\nnwIDAQAB\n-----END PUBLIC KEY-----\n');

-- --------------------------------------------------------

--
-- Table structure for table `privilages`
--

CREATE TABLE `privilages` (
  `Ename` varchar(255) NOT NULL,
  `Bat` varchar(255) NOT NULL,
  `Reg` varchar(255) NOT NULL,
  `Download` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privilages`
--

INSERT INTO `privilages` (`Ename`, `Bat`, `Reg`, `Download`) VALUES
('Suresh', 'B1', 'R1', 'true'),
('Vijay', 'B1', 'R1', 'true'),
('Vijay', 'B2', 'R2', 'true'),
('Vijay', 'B3', 'R3', 'true'),
('Vijay', 'B4', 'R4', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `reg_ka`
--

CREATE TABLE `reg_ka` (
  `EName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `Battalion` varchar(255) NOT NULL,
  `Region` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_ka`
--

INSERT INTO `reg_ka` (`EName`, `password`, `Battalion`, `Region`) VALUES
('Ajay', 'Test@123', 'B1', 'R1'),
('Suresh', 'Test@123', 'B1', 'R1'),
('Vijay', 'Test@123', 'B1', 'R1');

-- --------------------------------------------------------

--
-- Table structure for table `snfiles`
--

CREATE TABLE `snfiles` (
  `Fname` varchar(255) NOT NULL,
  `Sk` text NOT NULL,
  `KA` text NOT NULL,
  `Batalion` text NOT NULL,
  `Region` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `snfiles`
--

INSERT INTO `snfiles` (`Fname`, `Sk`, `KA`, `Batalion`, `Region`) VALUES
('AES.py', 'TgCjAI2PuWOA6KE9yOdEWSH6GC0lUII4K1Xl4WrwQIPQWooe7+kyPw100aCMUjBnNQONOd7bm2DiVSnaV3mqzr+qaeKUG1BcN2+EU/Q2ApP5sj4d6EOvyFR7+QxghVfGI8SAzo3Q126tfYsJfpxIDSiz1kf/sBs9b/gfD5REWtYasVUmzb13MIHJMEF2ciIo3YDn3xeLJ4nXKn3fuEhkQdyhVk0JBfjsqZFKeLDkUKaSart92G6o83TvfLfgRFODL3n/ajae3/nYr//c3suU/UhlcNlzvX6EV2lNKWhVyhkt3rQt46RQngDWRRISjnPZ/uKP7WyGFWdyIQIwYB1c0LEOjud6jhIcLFJ4zsE3nlOq8Hrf4MiPUuKvTXBfLmGu4WjeNQ2au15L5Zi3ouNqodkKVSl+eRHAM2jHxhLJ5TRbQORgXH5Y4ZYN/REPaAGDOeU06ndaLoUaBRMc0IVoHn9w+d2WHqjsajZMvrCwCYwe0DBXRRwUAOHRoSNr0x2AwXxgBeqpkP7XbCuUmOb7Ul+j5P60lokXsCwMOJBvU7ZNVxWL5/rV1YlB/YYYEblktJNtXmjSsmMQjNgyi5y8lLGLx7a0Vi8KberwrF1BPQs8Jw5uviTRu5rh4G//vQ3u', 'KA1', 'HL/XPKLILsPrehEBJXqyigX/keZJZMj0syKnLCgx3bs=', 'tyXG11LglPThavwTbmkIwsYUh3jYFZod6XHc5zMjwgs='),
('Dbcon.py', 'ko1F+IhR4R0a8YPO95cMUyI9Y9S2i8oDCjhRWRiU+2QEyUtLFzhF6A4vos9puDOU4DVAJy34wrQTRMEXWkv26JGY1vKL1mkWwiCTjNzD9yw3MXBWSftrn4Gf6t/nQonU9vYG8vOwtUSFG9PFdhhsTQpdjOdREzkKWMTZk1IpWNfNoaBjMJtb1RfrFidX3A79n1EvUnQQQtZdScrmcXdSklrB4ziUCGYMu5vzx9B6g6QFwpINO7FfKNd1Dcqt16mJa3ZsrNEHbKGkaJAj824xN/XgI0F1WiaaxFEuKRIFU84UIsLguI/YCwJ4OedF0gykFOstdI6MFaI0EimHJHbb/R7JiKKXWM91BpeBTP+YcpdQGmNe0UkN22EHJKfKxnIIW3asfF75jGLn+JunBxe8ZYxV605qOhtsPWJCdNWWJUXQpardTazRuBkyQCj9baVjBvUWM1x97CY5zcTC0x0Y7JYhX1QKKmge7/VDNte2DonxokCoSMTEQKedIiP5RJWz9ikN0g5pzw05t5oo2015hjeM3QjQP/hNZR0f+ADS01nm6p7httKSgpI/39S0F7Sgywvtx5kQdQHSrVfiyYeHPolka7h80lHmeNURkbKEDgjcw6q/1n6a4hhNQ9MOqFKo', 'KA3', 'lXyzHhXIaFBTVlnC5AQhHf5pXArjZ1Mj0qSlqKugUA4=', 'umNu8IPDM0Xq+GwbYnDjV6svlg58tPVIvp3+oAEHcy0='),
('test.py', 'UkwKdLyvThPi2kJV4Yrm+Uc9JUxRuL94cCKQcnyEYdm/QIudiYqFaCxClqg5nNE/0YeE9dM6yj1Tk492kNDqq6UGPWsA/ijs8TLvIdZ8Un91U/oNfI05BrKP6rWU2VWqu48gVAwTRSb9onKDZRnombb8T+YzDXdqg++hmt5t6Oo6GjufF2RwEfdMmDVFUE1dHBsWVrT0BdGj/SOtWZmM/sSx7SXHPkSIIuXoG7meYqBziqW1+InOzYY+eKL94VpST+iANcLfXkBt/AhBWBZWKMt9EGnTBYwpwoqIiokUuSmBnch8+iRtS8ZMT3geqiIe9UqSw+qW4lRLRn7XeEUXlVJU5vC4+rhn7K0DxORvuVAEM568FVDaFWe5xBLYkrYEMNvgoOgnkM4dazWboABXSpkJYcYj5jw2Zx7XzRpsIOJI7EFl5eB9JG/l4swQLFxkMSYMHtqFK4pImyVnlaifRQVsBhpFWXLKJhb1ahRljVPU+vlSK144CMgUOoZypWw/D1yFKgWgjZoU1nIeo7n0OuKUBl5ddbHdF79/vVUMkH28EvAvICC4URwXdjcZJpxm/sFxezHlsfKrW6QphbOpNnqqlOEHgzR4EM7nzu2sjW6y86+X7c5TIhG9PXUxO0I1', 'KA1', 'FNgt2znUOnzr9uhh+TyE/syaEWhZh9KVrtrmQweT54E=', 'nxxCv6lKhp6baUYR1ElwFroMB1jO2Tuau+UJcpisOqE='),
('rsa.py', 'm5eYTDkHA9Iq8UcQ+dy4/gXKZ++zGwZ9k1t+eL0QbODLGBrrN+mocz1wZVOb1U4SaTUC0tFUjJWXisMxXmHisq6HTFmlhxgshRpR3EDxwhBcNdUEMoCGJFUqbGVEGaGr/kvmcqEbLUF/Nbxz7/LZD5vYG9RHQ7TM9GEZMOvFRnIilMSvbxsYzbYaAoCOu0ukH8j72cnzu8Dfe91BTajOQPell0EcSPTiNqjswqY+KNk/oOWJsfTIbuVzoGVHEH18RanzSTpomnwNwE+nQti++879Au1dIpoHV9P6e4BL5IG200PVl1H3k8LFZ1ObEQ6oiY1hqM7xU3IAXhd5J29qwLWP0eTRJpeTt5um/cLcGbKBLvU7fw7HXDYL6E/9SJWrFfR4vflMynBaECMJwgZk5CRKp70asueCaUqsFk1sO+tvqx6ybgH1+6ncu+pIttoMpdqYSHcNVMgxuOd+JneX6aqe+75XpTDzzzJBzc/PoaAjasnVklFtUqJrywg0Ee3PzlWoQNhdcAfiuR6jx74F/JatTNC1ZSiOt8hpdD0uhgCI1SvsJjdSUUO3lTqqqrk0j2QNBDXx3TfNKdgTmpqi9pyAHIkkvPs+Xs8CZOfX0QOXw02qJ6ZO1EUhmrkjGkBh', 'KA1', 'lyUdtc7IZ6/nRs+EQbDpI028x57uWtASoYDRt621gps=', 'QGPtSSeBrOgVgDIBoOKQ1QoTBeo/lSAe0cBd6EGG9ME='),
('server.py', 'nIJ1UO/o5Zwr17zYvvYdFbD3Wh5g4lK6hV3V2cLc3MLSKiyAhpcULcjPdFHY8b1m67BlI7rpCymCsj09fDH4Tc9Sf2dsQa9Aexb3wFC82uhyKbaN/gOuVhLRZ1FNix+7wFCXxwjkZLpJIt1PcsI9vA1QY7Iw0X8o114h1skynH+R5ehBXwFZ6GqaaZw7/IcgLpa1uUPJon4cjnuPMFHDIHo1EzDURZ6RdZ+on1tJ6DTi+Hu/oeEAcqbDT8tsiRm/0fTxrDpZ0XbPSaX8pouhYfeuIyOFVnoRRJJVLqmu9MLnb3W/8bfjyT2DsGdtBXFmtxgVYWVcrEHepSF6h/J3/KB/ZuF7l/PlfzUdVPFMrEPIR6t6EeqVfm0aXMY0JS12RkwhYIjCQbhI3LuX15eu64TMYWl79f9gdDTFbRI6/uNhcJZ04O+7qjiky0vMwziVVzRcFj6rru2j7DYyrT4+Je5Cv3dHocLg91j4A5fcGgxc+ABopT38BlGmMsRYM+9fROMHvCejgozonLUa1D88w1JiDaClgsektX4H4W+iQUEtWltOTM3OT2vCX1vqtEx3nhnDQ2me9NyKG2BSwgxR7v+kkPm/35eZpfoFgJpFEE7URYHAbIVpNjR5N43u0UBa', 'KA3', 'rCxSBBVdMaWiAaUekEWb5Xyy0lBCAoCOXNo0IF4q9g4=', 'bFGB1JIU6dU+/Mojtm10ud/1d4RWP0jX9CeoGexVh0s='),
('sender.py', '5cFfNWluFvhxLuKCcnwmFM8NNOQyVgnA6X2jTNXDeWrHPSSYt62w1PLWScBvFvF85YdX5BVuyKAW08B5h8GyK0HDtLhRHoVDfzs/YbgO339uhU3Q9MLL/xRVssl+yuU3l5m5hHGhKIbenmLRsV8BVDwqLN3flOEFCrdtmLadKE3GN1FK2icglF++jfQL/fjH+vwN7NHFUiAzt49VF1nA/zOZ2UBQArUUhQUSdfstYBR/xqULLRS70PKPhxkQfEQQOS7SzcXm6/mPpHQN6XxZxL0R7ed+FQZ+Dq/GGyp5jihJ8OWJQ3KUpRJAOyL1icVeeousfjbndh2GQxYYHGFcR9lGIyaHfbhBhA/N2XplqUuyJ+0aa/bgPQqIUdKqPMJWo+N3s/ncSh5UczoREGescQfA0ZxNIu9LZ+3uDk/9bhBGqCmxg5zir+kcMBU2FgM0eVDOkkpmFZCaOYUrjHLczvdcU78jZ0DalvWqqO+aJZ+ADekXfSs+7YmSXJqozvaATyxGJAjezJQ69+5jvvL+541S/HPz4r0CF0Vf2NlrRcoOg3rn4ck7967AwT4T/5fkY2/YGDm5z+CJs+WMwXYcY1Wj0vSqetvcYgtwDgVs+6lZV6w4lV/bWwvM8Cmz9wQl', 'KA1', 'mk1e3uNqOx2z3peeSrIuW0M71BCJv9GP+xf8yR9FDpc=', 'DOq9HiLVOtSzcvPTeYzmBebKT7CJWCk77NoBkahYXb4='),
('client.py', '47CfRlb+5XDufl9VDPfXw44+CeYPaMzKSfe0cdgcj67mCb7Oy6yjv40GPCnmllw6aM5H3Ygrc+dhT493RhN1QGtimG02ZNb8XHqpxpc0desAfApTF2yI3QVIo4VEBOcCLsleQtIaFJaUHu+RGhmc7L4L/hYNVI75FbNKP3kCLmuR5so+QijyfKWLhPW19tip/fl4jlnl+xoOsmxMNXCy70Spp7swXH7FED6rJJR0/TiPdUZ6ZREAMs2Cx46W0KifsUg+3sqwD3J0K3+8kPmpoH3JzPMLsX8jlT84LJ/yohgnE90mv1aVIdF2iRq4XpjAYSrOF8OtmobRwxiy0Svk64Gc7s8JVHRlxFUbNrwdXZ3eqOb4GlWDatpAEKFjZizPysKI03YkSFhXCDlTi3KybMzml6dypKTeiy/wNPeRcF4XPm+0kIz/aF9Etl78coP2YztmmiaBOZD87e33fsr4AfF7LtpkLjBH630sO580MeyWw5ObsA0HZ7E0jWc/UIGPNPSN8FDCkTJ0maBvBnfNa6b4p4fwZlZ0daIvMDVGZnaCN7pXY1J+7FzGsDO5uI8eaborC4eOGVd+0t4DZQF0/sWIrOs2+8ShmumV4KzcmGj/FNaKrZGsVQVpDPQMaaSH', 'KA2', 'SB8LCcdd3cpOZwjJSLlIXsNmIo3cZH87OyKT8IUN7FE=', 'dV1jBW/xu2aC6zUo08nq2Qvg65n+6EAndK94cU5gSxY=');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keys_ka1`
--
ALTER TABLE `keys_ka1`
  ADD UNIQUE KEY `Fname` (`Fname`);

--
-- Indexes for table `keys_ka2`
--
ALTER TABLE `keys_ka2`
  ADD UNIQUE KEY `Fname` (`Fname`);

--
-- Indexes for table `keys_ka3`
--
ALTER TABLE `keys_ka3`
  ADD UNIQUE KEY `Fname` (`Fname`);

--
-- Indexes for table `privilages`
--
ALTER TABLE `privilages`
  ADD UNIQUE KEY `Ename` (`Ename`,`Bat`,`Reg`);

--
-- Indexes for table `reg_ka`
--
ALTER TABLE `reg_ka`
  ADD UNIQUE KEY `EName` (`EName`);

--
-- Indexes for table `snfiles`
--
ALTER TABLE `snfiles`
  ADD UNIQUE KEY `Fname` (`Fname`,`KA`) USING HASH;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
