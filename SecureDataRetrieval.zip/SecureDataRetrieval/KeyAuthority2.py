from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import AES
import random
import socket
from Dbcon import db
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

# import thread module
from _thread import *
import threading                 
import json

ex=None
 
  
class Window(QWidget):
    label1=None
    btn1=btn2=btn3=btn4=None
    width=600
    height=400
    
    keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
    msgbox = None 
    
    tableWidget=None
    
    def __init__(self):
        super().__init__()
        
        self.initUI()
        
        
    def initUI(self):
        self.createLayout()
        self.msgbox=QMessageBox() 
        hbox = QHBoxLayout()
        
        windowLayout = QVBoxLayout()
        windowLayout.addWidget(self.horizontalGroupBox)
        self.setLayout(windowLayout)
        self.setStyleSheet("background-color:rgb(200,200,160);font-weight:900;font-size:20px;")
        
        self.setFixedSize(QSize(self.width, self.height))
        self.setWindowTitle('Key Authority 1::Secure Data Retrieval for Decentralized Disruption-Tolerant Military Networks') 
        self.show() 
        self.label1.setPixmap(self.pixmap.scaled( self.label1.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
        
        
    def createLayout(self):
    
        width = self.frameGeometry().width()
        height = self.frameGeometry().height()
    
        self.label1 = QLabel("")
		
		# Load image
        self.pixmap = QPixmap('Key Authority2.png')
        

		# Set image to label
        self.label1.setPixmap(self.pixmap)

        # Resize the label according to image size
        self.label1.resize(width,height)
        self.pixmap.scaled(width,height,  Qt.AspectRatioMode.KeepAspectRatio);  
        self.btn1 = QPushButton("View Users")  
        self.btn1.clicked.connect(self.viewusers)
        self.btn1.resize(int(width/5),height) 
        self.btn2 = QPushButton("View Privilages") 
        self.btn2.clicked.connect(self.viewprivilages)
        self.btn3 = QPushButton("View Keys") 
        self.btn3.clicked.connect(self.viewkeys)
        self.btn4 = QPushButton("Exit") 
        self.btn4.clicked.connect(self.closeit)
        self.tableWidget = QTableWidget()  
        self.tableWidget.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers) 
        self.tableWidget.setStyleSheet("QHeaderView::section { background-color:#ccc ;font-weight:900;}");
        self.tableWidget.verticalHeader().setVisible(False);
        self.horizontalGroupBox = QGroupBox("")
        layout = QGridLayout() 
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.label1,0,0,1,5)  
        layout.addWidget(self.btn1,1,4)      
        layout.addWidget(self.btn2,3,4)      
        layout.addWidget(self.btn3,5,4)      
        layout.addWidget(self.btn4,7,4)    
        layout.addWidget(self.tableWidget ,1,0,6,4)              
        self.horizontalGroupBox.setLayout(layout)
        
    def viewusers(self): 
      try:
        self.tableWidget.clear();
        self.tableWidget.setRowCount(1) 
        self.tableWidget.setColumnCount(3) 
        self.tableWidget.setHorizontalHeaderLabels(['Username', 'Batalion', 'Region']) 
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)   
        s.connect(("127.0.0.1",5656))    
                      
        data=["userlist"]
                                             
        s.sendall(json.dumps(data).encode("utf-8"))
                      
        BUFF_SIZE=2048
        while True:
                           data = s.recv(BUFF_SIZE)
                           if data: 
                               if len(data) >= BUFF_SIZE: 
                                 while True:
                                   part = s.recv(BUFF_SIZE)
                                   data += part
                                   if len(part) < BUFF_SIZE: 
                                      break
                               data=json.loads(data)  
                               break
        s.close() 
         
        i=0
        for row in data: 
          rowPosition = self.tableWidget.rowCount()
          self.tableWidget.insertRow(rowPosition)
          self.tableWidget.setItem(i,0, QTableWidgetItem(row[0]))
          self.tableWidget.setItem(i,1, QTableWidgetItem(row[2])) 
          self.tableWidget.setItem(i,2, QTableWidgetItem(row[3]))
          i+=1 
          
      except Exception as e:
               self.showmsg(str(e))              
        
        
    def viewprivilages(self): 
        self.tableWidget.clear();
        self.tableWidget.setRowCount(1) 
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("Username")) 
        self.tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("Batalion"))
        self.tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("Region"))
        self.tableWidget.setHorizontalHeaderItem(3, QTableWidgetItem("Download permission"))
        x=db()
        x.connect()
        records=x.execute("SELECT * FROM privilages") 
        i=0
        for row in records: 
          rowPosition = self.tableWidget.rowCount()
          self.tableWidget.insertRow(rowPosition)
          self.tableWidget.setItem(i,0, QTableWidgetItem(row[0]))
          self.tableWidget.setItem(i,1, QTableWidgetItem(row[1]))
          self.tableWidget.setItem(i,2, QTableWidgetItem(row[2]))
          self.tableWidget.setItem(i,3, QTableWidgetItem(row[3]))
          i+=1
          
        x.close()
        

    def viewkeys(self): 
        self.tableWidget.clear();
        self.tableWidget.setRowCount(1) 
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("Filename")) 
        self.tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("Key")) 
        x=db()
        x.connect()
        records=x.execute("SELECT * FROM keys_ka2") 
        i=0
        for row in records: 
          rowPosition = self.tableWidget.rowCount()
          self.tableWidget.insertRow(rowPosition)
          self.tableWidget.setItem(i,0, QTableWidgetItem(row[0]))
          self.tableWidget.setItem(i,1, QTableWidgetItem(row[1])) 
          i+=1
          
        x.close()    
                      
    def showmsg(self,msg):
            self.msgbox.setText(msg) 
            self.msgbox.setWindowTitle("Information MessageBox") 
            self.msgbox.setStandardButtons(QMessageBox.Ok) 
            retval = self.msgbox.exec_()

        
    def closeit(self): 
        self.close()       
 
# thread fuction
def threaded1(c):
    global ex
    while True: 
        # data received from client
      data = c.recv(2048)
      if not data: 
            # lock released on exit 
            break
      else:
        fname=data.decode('utf-8')
        '''
        # generate private/public key pair
        key = rsa.generate_private_key(backend=default_backend(), public_exponent=65537, \
          key_size=2048)

        # get public key in OpenSSH format
        public_key = key.public_key().public_bytes(serialization.Encoding.PEM, \
           serialization.PublicFormat.SubjectPublicKeyInfo)

        # get private key in PEM container format
        pem = key.private_bytes(encoding=serialization.Encoding.PEM,
           format=serialization.PrivateFormat.TraditionalOpenSSL,
           encryption_algorithm=serialization.NoEncryption())

        # decode to printable strings
        private_key_str = pem.decode('utf-8')
        public_key_str = public_key.decode('utf-8')        
        secretkey=public_key_str'''
        private_key_str=AES.generate_key()
        public_key_str=AES.generate_key()
        secretkey=public_key_str
        x=db()
        x.connect() 
        records=x.execute("select * from keys_ka2 where Fname='"+str(fname)+"'")
        verifier=None
        for row in records: 
                verifier=row 
        if verifier==None:
          x.update("insert into keys_ka2(`Fname`, `Keys`) values(%s,%s)",(str(fname),str(secretkey)))
          c.sendall(json.dumps([1,public_key_str]).encode("utf-8")) 
        else:
          c.sendall(json.dumps([0,"File already found on server,use different file name"]).encode("utf-8"))  
        x.close()   
        break         
 

def listenport1(host,port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(5)
        while True:

        # establish connection with client
               c, addr = s.accept()

        # lock acquired by client 
        # Start a new thread and return its identifier
               start_new_thread(threaded1, (c,))
        s.close()
        

def main(): 
    start_new_thread(listenport1, ("127.0.0.1",2999))
    app = QApplication(sys.argv)
    ex = Window()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()