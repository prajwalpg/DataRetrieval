from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import AES
import random
import socket
from Dbcon import db 

# import thread module
from _thread import *
import threading                 
import json

ex=None

keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
    
class Window(QWidget):
    label1=None
    btn1=btn2=btn3=btn4=None
    msgbox = None 
    width=600
    height=600
    
    tableWidget=None
    
    def __init__(self):
        super().__init__()
        self.initUI()
        
        
    def initUI(self):
        self.createLayout()
        self.msgbox=QMessageBox() 
        hbox = QHBoxLayout()
        
        windowLayout = QVBoxLayout()
        windowLayout.addWidget(self.horizontalGroupBox)
        self.setLayout(windowLayout)
        self.setStyleSheet("background-color:#fff;font-weight:900;font-size:20px;")
        
        self.setFixedSize(QSize(self.width, self.height))
        self.setWindowTitle('Storage Node::Secure Data Retrieval for Decentralized Disruption-Tolerant Military Networks') 
        self.show() 
        self.label1.setPixmap(self.pixmap.scaled( self.label1.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
        
        
    def createLayout(self):
    
        width = self.frameGeometry().width()
        height = self.frameGeometry().height()
    
        self.label1 = QLabel("")
		
		# Load image
        self.pixmap = QPixmap('StorageNode.png')
        

		# Set image to label
        self.label1.setPixmap(self.pixmap)

        # Resize the label according to image size
        self.label1.resize(width,height) 
         
        self.btn1 = QPushButton("View Files Stored")
        self.btn1.clicked.connect(self.viewfiles)    
        self.btn2 = QPushButton("View Attackers List")
        self.btn2.clicked.connect(self.viewattackers)  
        
        self.btn3 = QPushButton("Unblock selected")
        self.btn3.clicked.connect(self.unblockselected)  
        self.btn3.setVisible(False)
        
        self.tableWidget = QTableWidget()  
        self.tableWidget.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tableWidget.setStyleSheet("QHeaderView::section { background-color:#ccc;font-weight:900; }");
        self.tableWidget.verticalHeader().setVisible(False);
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows);
        
        self.horizontalGroupBox = QGroupBox("")
        layout = QGridLayout() 
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.label1,0,0,1,3)  
        layout.addWidget(QLabel("Storage Node"),1,0,1,3)  
        layout.addWidget(self.tableWidget,2,0,1,3)  
        layout.addWidget(self.btn1,3,0)  
        layout.addWidget(self.btn2,3,1)     
        layout.addWidget(self.btn3,3,2)             
        self.horizontalGroupBox.setLayout(layout)

    def viewfiles(self):  
        self.btn3.setVisible(False)
        self.tableWidget.clear();
        self.tableWidget.setRowCount(1) 
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("FileName"))
        self.tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("Secret Key"))
        self.tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("Key Authority"))
        self.tableWidget.setHorizontalHeaderItem(3, QTableWidgetItem("Batalion"))
        self.tableWidget.setHorizontalHeaderItem(4, QTableWidgetItem("Region"))
        x=db()
        x.connect()
        records=x.execute("SELECT * FROM snfiles") 
        i=0
        for row in records: 
          rowPosition = self.tableWidget.rowCount()
          self.tableWidget.insertRow(rowPosition)
          self.tableWidget.setItem(i,0, QTableWidgetItem(row[0]))
          self.tableWidget.setItem(i,1, QTableWidgetItem(row[1]))
          self.tableWidget.setItem(i,2, QTableWidgetItem(row[2]))
          self.tableWidget.setItem(i,3, QTableWidgetItem(row[3]))
          self.tableWidget.setItem(i,4, QTableWidgetItem(row[4]))
          i+=1
          
        x.close()
        
    def viewattackers(self):  
    
        self.btn3.setVisible(True)
        self.tableWidget.clear();
        self.tableWidget.setRowCount(1) 
        self.tableWidget.setColumnCount(6)
        self.tableWidget.setHorizontalHeaderItem(0, QTableWidgetItem("Attacker Name"))
        self.tableWidget.setHorizontalHeaderItem(1, QTableWidgetItem("Attacker File"))
        self.tableWidget.setHorizontalHeaderItem(2, QTableWidgetItem("Used Key"))
        self.tableWidget.setHorizontalHeaderItem(3, QTableWidgetItem("Attacked Batalion"))
        self.tableWidget.setHorizontalHeaderItem(4, QTableWidgetItem("Attacked Region"))
        self.tableWidget.setHorizontalHeaderItem(5, QTableWidgetItem("Attacked tym"))
        x=db()
        x.connect()
        records=x.execute("SELECT * FROM attackers") 
        i=0
        for row in records: 
          rowPosition = self.tableWidget.rowCount()
          self.tableWidget.insertRow(rowPosition)
          self.tableWidget.setItem(i,0, QTableWidgetItem(row[0]))
          self.tableWidget.setItem(i,1, QTableWidgetItem(row[1]))
          self.tableWidget.setItem(i,2, QTableWidgetItem(row[2]))
          self.tableWidget.setItem(i,3, QTableWidgetItem(row[3]))
          self.tableWidget.setItem(i,4, QTableWidgetItem(row[4])) 
          self.tableWidget.setItem(i,5, QTableWidgetItem(str(row[5])))
          i+=1
          
        x.close()      
       
        
    def unblockselected(self):    
        rowList = self.tableWidget.selectionModel().selectedRows(); 
        if len(rowList)==0:
           self.showmsg("No Row selected")
        for  index in rowList:
           rowNumber = index.row();
           if self.tableWidget.item(rowNumber, 0):
              it1 = self.tableWidget.item(rowNumber, 0).text() 
              it2 = self.tableWidget.item(rowNumber, 1).text() 
              it3 = self.tableWidget.item(rowNumber, 2).text() 
              it4 = self.tableWidget.item(rowNumber, 3).text() 
              it5 = self.tableWidget.item(rowNumber, 4).text() 
              x=db()
              x.connect()
              x.update("delete FROM attackers where `Aname`='"+it1+"'  and    `Akey`='"+it3+"'  and  `ABat`='"+it4+"'  and  `AReg`='"+it5+"'",()) 
              x.close()        
              self.showmsg("Unblocked!")
              self.viewattackers()

    def showmsg(self,msg):
            self.msgbox.setText(msg) 
            self.msgbox.setWindowTitle("Information MessageBox") 
            self.msgbox.setStandardButtons(QMessageBox.Ok) 
            retval = self.msgbox.exec_()
           
    
# thread fuction
def threaded1(c):
    BUFF_SIZE=2048
    while True:

        # data received from client
      data = c.recv(BUFF_SIZE)
      if not data: 
            # lock released on exit 
            break
      else:
        if len(data) >= BUFF_SIZE: 
          while True:
           part = c.recv(BUFF_SIZE)
           data += part
           if len(part) < BUFF_SIZE: 
                 break
        data=json.loads(data)         
        fname=data[0] 
        sk=data[1] 
        content=data[2].encode("utf-8")
        Aut=data[3] 
        Bat=data[4] 
        Reg=data[5]  
        x=db()
        x.connect() 
        x.update("insert into snfiles(`Fname`, `Sk`, `KA`, `Batalion`, `Region`) values(%s,%s,%s,%s,%s)",(str(fname),str(sk),str(Aut),str(Bat),str(Reg))) 
        x.close()  
        f=open("StorageNode//"+fname,"wb")
        f.write(content)        
        f.close()
        
        c2= socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        c2.connect(("127.0.0.1",1299)) 
        data=["upload",fname,sk,Aut,Bat,Reg]
        c2.sendall(json.dumps(data).encode("utf-8"))
        c2.close()
        if ex!=None: ex.viewfiles() 
        break         
 
def threaded2(c):
    BUFF_SIZE=2048
    x=db()
    x.connect() 
    while True:

        # data received from client
      data = c.recv(BUFF_SIZE)
      if not data: 
            # lock released on exit 
            break
      else:
        if len(data) >= BUFF_SIZE: 
         while True:
           part = c.recv(BUFF_SIZE)
           data += part
           if len(part) < BUFF_SIZE: 
                 break
        print("Received File Request")        
        data=json.loads(data)
        oname=data[0]        
        fname=data[1] 
        sk=data[2]   
        Bat=data[3] 
        Reg=data[4] 
        rtecords=x.execute("select * from snfiles where Fname='"+fname+"'") 
        verifier=None
        for row in rtecords: 
           '''sk1=AES.decrypt(row[1],keyWord).decode("utf-8") 
           Bat1=AES.decrypt(row[3],keyWord).decode("utf-8") 
           Reg1=AES.decrypt(row[4],keyWord).decode("utf-8") 
           if sk1==sk and Bat1==Bat and   Reg1==Reg:'''
           verifier=row
           break;
               
        c2= socket.socket(socket.AF_INET, socket.SOCK_STREAM)                   
        c2.connect(("127.0.0.1",3292)) 
        if verifier:   
        
           print("file:"+fname+"/"+verifier[2])     
           data.append(verifier[2])
           print("Sent key Request") 
           c1= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
           c1.connect(("127.0.0.1",7887)) 
           c1.sendall(json.dumps(data).encode("utf-8"))
           while True:
              data = c1.recv(BUFF_SIZE)
              if not data:   
                 break
              else:
                 if len(data) >= BUFF_SIZE: 
                   while True:
                      part = c1.recv(BUFF_SIZE)
                      data += part
                      if len(part) < BUFF_SIZE: 
                         break
                 
                 print("Received key")         
                 data=json.loads(data) 
                 data1=[]
                 print(data)
                 if data[0].lower()=="success".lower():
                       rtecords=x.execute("select * from attackers where Aname='"+oname+"'") 
                       verifier1=None
                       for row in rtecords: 
                           verifier1=row
                       if verifier1!=None:
                            c2.sendall(json.dumps([verifier[2],"Blocked"]).encode("utf-8"))
                            c.sendall(json.dumps(["Blocked","Data"]).encode("utf-8"))
                       else: 
                            c2.sendall(json.dumps([verifier[2],"Data"]).encode("utf-8"))  
                            f=open("StorageNode//"+fname,"rb") 
                            c.sendall(json.dumps(["Success",AES.decrypt(f.read(),keyWord).decode("utf-8")]).encode("utf-8")) 
                            f.close()                    
                 else:         
                    rtecords=x.execute("select * from attackers where Aname='"+oname+"'") 
                    verifier1=None
                    for row in rtecords: 
                           verifier1=row    
                    if verifier1==None:                           
                       x.update("insert into attackers(`Aname`, `Afile`, `Akey`, `ABat`, `AReg`) values(%s,%s,%s,%s,%s)",(oname,fname,sk,Bat,Reg)) 
                    c2.sendall(json.dumps([verifier[2],"Failure"]).encode("utf-8"))  
                    c.sendall(json.dumps(["Failure","No data"]).encode("utf-8"))
        else:
                c2.sendall(json.dumps(["Download","Failure"]).encode("utf-8"))  
                c.sendall(json.dumps(["Failure","No Such File"]).encode("utf-8"))  
        break           
        c2.close()                        
 
    x.close()             


def listenport1(host,port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(5)
        while True:

        # establish connection with client
               c, addr = s.accept()

        # lock acquired by client 
               print("Checking for file save request")        
               
        # Start a new thread and return its identifier
               start_new_thread(threaded1, (c,))
        s.close()


def listenport2(host,port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(5)
        while True:

        # establish connection with client
               c, addr = s.accept()

        # lock acquired by client 
               print("Checking for file read request")        
        # Start a new thread and return its identifier
               start_new_thread(threaded2, (c,))
               print("End checking  for file request")       
                              
        s.close()

 
def main(): 
    start_new_thread(listenport1, ("127.0.0.1",5555))
    start_new_thread(listenport2, ("127.0.0.1",7788))
    app = QApplication(sys.argv)
    ex = Window()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()