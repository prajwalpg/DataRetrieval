from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import AES
import random
import socket
from pathlib import Path    
import json

global ex
 
  
class Window(QWidget):
    label1=label2=label3=label4=label5=None
    btn1=btn2=btn3=btn4=None
    KA=None;
    keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
    msgbox = None 
    width=800
    height=400
    
    content=None
    
    def __init__(self):
        super().__init__()
        
        self.initUI()
        
        
    def initUI(self):
        self.createLayout()
        self.msgbox=QMessageBox() 
        hbox = QHBoxLayout()
        
        windowLayout = QVBoxLayout()
        windowLayout.addWidget(self.horizontalGroupBox)
        self.setLayout(windowLayout)
        self.setStyleSheet("background-color:rgb(122,2,192);font-weight:900;font-size:30px;")
        
        self.setFixedSize(QSize(self.width, self.height))
        self.setWindowTitle('Sender ::Secure Data Retrieval for Decentralized Disruption-Tolerant Military Networks')
        self.show() 
        self.label1.setPixmap(self.pixmap.scaled( self.label1.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
        
        
    def createLayout(self):
    
        width = self.frameGeometry().width()
        height = self.frameGeometry().height()
    
        self.label1 = QLabel("")
		
		# Load image
        self.pixmap = QPixmap('sender.png')
        

		# Set image to label
        self.label1.setPixmap(self.pixmap)

        # Resize the label according to image size
        self.label1.resize(width,height)
        self.pixmap.scaled(width,height,  Qt.AspectRatioMode.KeepAspectRatio); 
        self.label2 = QLabel("File Name:") 
        self.label2.resize(int(width/5),height)
        self.label3 = QLabel("")
        self.label3.resize(int(width/2),height)        
        self.label4 = QLabel("Secret Key:") 
        self.label4.resize(int(width/5),height) 
        self.label5 = QLabel("") 
        self.label4.resize(int(width/2),height) 
        self.btn1 = QPushButton("Browse")  
        self.btn1.clicked.connect(self.browse_path)
        self.btn1.resize(int(width/5),height) 
        self.btn2 = QPushButton("Encrypt") 
        self.btn2.clicked.connect(self.encryptfile)
        self.btn3 = QPushButton("Get Key from KA") 
        self.btn3.clicked.connect(self.getKeyFromKA)
        self.btn4 = QPushButton("Upload") 
        self.btn4.clicked.connect(self.upload)
        self.content= QPlainTextEdit() 
        self.content.setStyleSheet("background-color:blue;") 
        
        self.horizontalGroupBox = QGroupBox("")
        layout = QGridLayout() 
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.label1,0,0,1,5)
        layout.addWidget(self.label2,1,0)
        layout.addWidget(self.label3,1,1,1,4)
        layout.addWidget(self.label4,2,0)
        layout.addWidget(self.label5,2,1,1,4)  
        layout.addWidget(self.btn1,1,4)      
        layout.addWidget(self.btn2,3,4)      
        layout.addWidget(self.btn3,5,4)      
        layout.addWidget(self.btn4,7,4)    
        layout.addWidget(self.content,3,0,6,4)              
        self.horizontalGroupBox.setLayout(layout)
        
    def encryptfile(self): 
        if self.content.toPlainText():
           encrypted = AES.encrypt(self.content.toPlainText(), self.keyWord)
           self.content.setPlainText(encrypted.decode("utf-8"))
                      
    def browse_path(self):
        path, filter =QFileDialog.getOpenFileName(self, 'Select file', 
            '', 'All files (*)')
        if path:
            self.label3.setText(path) 
            self.fname= Path(path).name
            with open(path) as f:
                      self.content.setPlainText(f.read())      

    def getKeyFromKA(self): 
      try:
         if not  self.fname:
            return
         ports=[1999,2999,3999]   
         r1=random.randint(0, 2)                 
         msg=""
         self.KA="KA"+str(r1+1)
         s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) 
         print("Connecting port "+str(ports[r1])+"...")
         s.connect(("127.0.0.1", ports[r1]))
         msg="" 
         s.sendall( self.fname.encode("utf-8"))
         BUFF_SIZE=2048
         while True: 
        # data received from client
           data = s.recv(BUFF_SIZE)
           if not data:  
             break
           else:
             if len(data) >= BUFF_SIZE: 
                while True:
                   part = s.recv(BUFF_SIZE)
                   data += part
                   if len(part) < BUFF_SIZE: 
                      break
           break          
         data=json.loads(data)

         s.close()                
         if int(data[0])==1:
            self.label5.setText(data[1])
            msg+="Came FROM "+self.KA
            msg+="\n"+data[1]
            s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) 
            s.connect(("127.0.0.1", 1299)) 
            s.sendall(json.dumps([self.KA,self.fname,data[1]]).encode("utf-8"))  
            s.close()
            self.showmsg(msg) 
         else:
            self.showmsg(data[1])          
      except Exception as e:
               self.showmsg(str(e))              

    def upload(self):   
        self.optdialog = BROptionsDialog(self)
        self.optdialog.btn.clicked.connect(self.uploadnext)
        self.optdialog.exec() 
        
    def uploadnext(self):  
        try:
                      sk=self.label5.text()
                      content=self.content.toPlainText()
                      s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)  
                      s.connect((self.optdialog.text1.text(),5555))   
                      data=[self.fname,AES.encrypt(sk, self.keyWord).decode('utf-8'),content,self.KA,AES.encrypt(self.optdialog.combo1.currentText() , self.keyWord).decode('utf-8'),AES.encrypt(self.optdialog.combo2.currentText(), self.keyWord).decode('utf-8')]
                                             
                      s.sendall(json.dumps(data).encode("utf-8")) 
                      s.close()
                      s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
                      s.connect(("127.0.0.1", 1299)) 
                      s.sendall(json.dumps(["upload",self.fname,data[1],data[3],data[4]]).encode("utf-8"))  
                      s.close() 
                      self.showmsg("File Uploaded Successfully")
                      self.content.setPlainText("")
                      self.label3.setText("")
                      self.label5.setText("")
                      self.optdialog.close()
        except Exception as e:
               self.showmsg(str(e))              
                      
    def showmsg(self,msg):
            self.msgbox.setText(msg) 
            self.msgbox.setWindowTitle("Information MessageBox") 
            self.msgbox.setStandardButtons(QMessageBox.Ok) 
            retval = self.msgbox.exec_()

class BROptionsDialog(QDialog):
    btn=combo1=combo2=text1= None
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setWindowTitle('Details') 

        list1=["B1","B2","B3","B4"]
        list2=["R1","R2","R3","R4"]
        
        self.text1 = QLineEdit()
        
        self.combo1 = QComboBox()
        self.combo1.addItems(list1)
        
        self.combo2 = QComboBox()
        self.combo2.addItems(list2)
        
        self.btn = QPushButton("Next") 

        vbox = QVBoxLayout()
        vbox.addWidget(QLabel("Storage Node Address:"))
        vbox.addWidget(self.text1)
        vbox.addWidget(QLabel("Batalion"))
        vbox.addWidget(self.combo1)
        vbox.addWidget(QLabel("Region"))
        vbox.addWidget(self.combo2)
        vbox.addWidget(self.btn)
         
        self.setLayout(vbox)
        
def main():

    app = QApplication(sys.argv)
    ex = Window()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()