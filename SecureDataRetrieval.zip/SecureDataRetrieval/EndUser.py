from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import AES
import random
import socket 
import json

  
class Window(QWidget):
    label1=None
    btn1=btn2=btn3=btn4=None
    name=None
    keyWord = "ef50a0ef2c3e3a5fdf803ae9752c8c66"
    msgbox = None 
    width=600
    height=600
    
    tableWidget=None
    
    def __init__(self,name):
        super().__init__()
        self.name=name
        self.initUI()
        
        
    def initUI(self):
        self.createLayout()
        self.msgbox=QMessageBox() 
        hbox = QHBoxLayout()
        
        windowLayout = QVBoxLayout()
        windowLayout.addWidget(self.horizontalGroupBox)
        self.setLayout(windowLayout)
        
        self.setFixedSize(QSize(self.width, self.height))
        self.setWindowTitle('EndUser:'+self.name) 
        self.show() 
        self.label1.setPixmap(self.pixmap.scaled( self.label1.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
        
        
    def createLayout(self):
    
        width = self.frameGeometry().width()
        height = self.frameGeometry().height()
    
        self.label1 = QLabel("")
		
		# Load image
        self.pixmap = QPixmap('EndUser.png')
        

		# Set image to label
        self.label1.setPixmap(self.pixmap)

        # Resize the label according to image size
        self.label1.resize(width,height)
        self.pixmap.scaled(width,height,  Qt.AspectRatioMode.KeepAspectRatio); 
        
        
        
        self.label2= QLabel("")
		
		# Load image
        pixmap1 = QPixmap('enduser3.png')
        

		# Set image to label
        self.label2.setPixmap(pixmap1)  
        
        self.content= QPlainTextEdit()  
        self.btn1 = QPushButton("SAVE")
        self.btn1.clicked.connect(self.save)    
        self.btn2 = QPushButton("RECEIVE")
        self.btn2.clicked.connect(self.receive)  
        self.horizontalGroupBox = QGroupBox("")
        layout = QGridLayout() 
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.label1,0,0,1,3) 
        layout.addWidget(self.label2,1,2,3,2) 
        layout.addWidget(self.content,1,0,1,2)  
        layout.addWidget(self.btn1,2,0)  
        layout.addWidget(self.btn2,2,1)         
        self.horizontalGroupBox.setLayout(layout)

    def save(self): 
        fname, done1 = QInputDialog.getText(
             self, 'Input Dialog', 'Enter The fileName to Be Saved:')
        if not done1:
               return
        f=open("downloads//"+fname,"wb")
        f.write(self.content.toPlainText().encode('utf-8'))        
        f.close()
        QMessageBox.about(self, "Message", "File Stored in Downloads")
        
    def receive(self):
        self.optdialog = BROptionsDialog(self)
        self.optdialog.btn.clicked.connect(self.receivenext)
        self.optdialog.exec()  
        
    def receivenext(self):   
                      if self.optdialog.text1.text()=="":
                          return
                      s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)  
                      print("Connecting "+self.optdialog.text1.text()+"....")
                      s.connect((self.optdialog.text1.text(),7788))    
                      
                      data=[self.name,self.optdialog.text2.text(),self.optdialog.text3.text(),self.optdialog.combo1.currentText(),self.optdialog.combo2.currentText()]
                                             
                      s.sendall(json.dumps(data).encode("utf-8"))
                      
                      BUFF_SIZE=2048
                      while True:
                           data = s.recv(BUFF_SIZE)
                           if data: 
                               if len(data) >= BUFF_SIZE: 
                                 while True:
                                   part = s.recv(BUFF_SIZE)
                                   data += part
                                   if len(part) < BUFF_SIZE: 
                                      break
                               data=json.loads(data)   
                               if data[0].lower()=="Success".lower():
                                  self.showmsg("File Recieved Successfully")
                                  self.content.setPlainText(data[1])
                               elif data[0].lower()=="failure".lower():
                                  self.showmsg("Invalid Details..,One of the Credentials(SK or Region or Batalion) ")
                               elif data[0].lower()=="Blocked".lower():                               
                                  self.showmsg("valid Details...! But u Blocked")
                               break
                      s.close()                        
                      self.optdialog.close()
                      
    def showmsg(self,msg):
            self.msgbox.setText(msg) 
            self.msgbox.setWindowTitle("Information MessageBox") 
            self.msgbox.setStandardButtons(QMessageBox.Ok) 
            retval = self.msgbox.exec_()
            
class BROptionsDialog(QDialog):
    btn=combo1=combo2=text1= None
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setWindowTitle('Details') 
        list1=["B1","B2","B3","B4"]
        list2=["R1","R2","R3","R4"]
        
        self.text1 = QLineEdit()
        self.text2 = QLineEdit()
        self.text3 = QLineEdit()
        
        self.combo1 = QComboBox()
        self.combo1.addItems(list1)
        
        self.combo2 = QComboBox()
        self.combo2.addItems(list2)
        
        self.btn = QPushButton("Next") 

        vbox = QVBoxLayout()
        vbox.addWidget(QLabel("Storage Node Address:"))
        vbox.addWidget(self.text1)
        vbox.addWidget(QLabel("Filename:"))
        vbox.addWidget(self.text2)
        vbox.addWidget(QLabel("Enter secret key:"))
        vbox.addWidget(self.text3)
        vbox.addWidget(QLabel("Batalion"))
        vbox.addWidget(self.combo1)
        vbox.addWidget(QLabel("Region"))
        vbox.addWidget(self.combo2)
        vbox.addWidget(self.btn)
         
        self.setLayout(vbox)
    

def main():  
    app = QApplication(sys.argv)
    ex = Window("Vijay")
    sys.exit(app.exec())


if __name__ == '__main__':
    main()